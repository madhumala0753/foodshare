# RescueRoute — Last-Mile Food Rescue

A responsive, front-end prototype for coordinating surplus food donations, volunteer riders, and receiving shelters under time and capacity uncertainty.

## Features

- Overview dashboard with urgent donation and network-readiness snapshots
- Add donations with quantity, pickup location, deadline, handling needs, and notes
- Search and filter the donation inventory
- Rule-based rider matching using capacity and basic handling-equipment compatibility
- Volunteer rider availability controls
- Receiving shelter capacity and handling requirements
- Demo data saved in the current browser using `localStorage`
- Responsive layout for desktop and mobile
- No build tools or package installation required

## Run locally

1. Download or extract this project.
2. Open the `rescueroute` folder in VS Code.
3. Open `index.html` in your browser. You can also install the **Live Server** VS Code extension and choose **Open with Live Server**.
4. Try adding a donation, opening the Dispatch Board, matching a rider, and changing rider availability.

## Publish using GitHub Pages

1. Create a GitHub repository, for example `rescueroute-food-rescue`.
2. In VS Code, open this project folder.
3. Open **Terminal → New Terminal** and run:

   ```bash
   git init
   git add .
   git commit -m "Build RescueRoute food rescue prototype"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/rescueroute-food-rescue.git
   git push -u origin main
   ```

   Replace `YOUR-USERNAME` with your GitHub username. If the repository already has a remote, check it with `git remote -v` before adding another.

4. On GitHub, open the repository and go to **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then click **Save**.
7. Wait for GitHub Pages to publish the site. The URL is usually `https://YOUR-USERNAME.github.io/rescueroute-food-rescue/`.

## Important prototype limitations

This is a front-end demo, not a production logistics platform.

- Data is stored only in the current browser; it does not sync between people or devices.
- There is no authentication, database, server, push notification, or live location/route service.
- Distance and travel-time values are sample estimates, not live navigation.
- Matching is a transparent heuristic and does not guarantee safe or optimal delivery.
- The prototype does not verify food safety, allergens, temperature, donor legitimacy, or shelter acceptance.
- A match is a suggested coordination action, not confirmation that a rider has accepted a delivery.

For a real deployment, add a secure backend/database, role-based access, verified partner workflows, reliable timestamps, audit history, notifications, and explicit confirmation at pickup and handoff. Do not put private keys or service credentials in a public GitHub repository.

## Reset the demo

The app stores demo changes under the browser key `rescueroute-demo-v1`. To reset, open browser developer tools → Console and run:

```js
localStorage.removeItem("rescueroute-demo-v1");
location.reload();
```

## Project files

- `index.html` — page structure and views
- `style.css` — responsive visual design
- `app.js` — sample data, local storage, filters, and matching interactions
- `README.md` — setup and publishing guide
- `.gitignore` — common local/editor files to exclude
