const STORAGE_KEY = "rescueroute-demo-v1";

const initialData = {
  donations: [
    {id:1,food:"Fresh vegetable boxes",donor:"Green Basket Cafe",quantity:42,location:"Koregaon Park",deadline:45,handling:"Standard",status:"Available",notes:"Mixed seasonal vegetables",emoji:"🥬",distance:3.2},
    {id:2,food:"Prepared lunch packs",donor:"Daily Grain Kitchen",quantity:30,location:"Shivajinagar",deadline:65,handling:"Keep warm",status:"Available",notes:"Packed lunch, confirm holding temperature",emoji:"🍱",distance:4.5},
    {id:3,food:"Bakery surplus",donor:"Sunrise Bakehouse",quantity:24,location:"Deccan",deadline:95,handling:"Fragile packaging",status:"Available",notes:"Keep boxes level",emoji:"🥖",distance:2.1},
    {id:4,food:"Dairy & yogurt packs",donor:"FreshMart",quantity:18,location:"Aundh",deadline:35,handling:"Keep chilled",status:"Available",notes:"Cold-chain confirmation required",emoji:"🥛",distance:5.4},
    {id:5,food:"Seasonal fruit crates",donor:"Orchard Corner",quantity:36,location:"Baner",deadline:180,handling:"Standard",status:"Matched",notes:"Crates can be stacked carefully",emoji:"🍎",distance:3.8},
    {id:6,food:"Sealed snack packs",donor:"Campus Canteen",quantity:50,location:"University Road",deadline:240,handling:"Standard",status:"Available",notes:"Factory-sealed snack packs",emoji:"🥪",distance:1.8}
  ],
  riders: [
    {id:1,name:"Aarav Mehta",vehicle:"Motorcycle",capacity:35,available:true,equipment:["Insulated bag"],distance:2.4,initials:"AM"},
    {id:2,name:"Sara Khan",vehicle:"Bicycle",capacity:20,available:true,equipment:["Secure crate"],distance:1.7,initials:"SK"},
    {id:3,name:"Rohan Patil",vehicle:"Scooter",capacity:55,available:true,equipment:["Insulated bag","Secure crate"],distance:3.1,initials:"RP"},
    {id:4,name:"Mira Joshi",vehicle:"Cargo e-bike",capacity:45,available:true,equipment:["Insulated bag","Secure crate"],distance:2.8,initials:"MJ"},
    {id:5,name:"Dev Shah",vehicle:"Bicycle",capacity:18,available:false,equipment:["Secure crate"],distance:4.2,initials:"DS"},
    {id:6,name:"Isha Rao",vehicle:"Scooter",capacity:40,available:false,equipment:["Insulated bag"],distance:3.5,initials:"IR"}
  ],
  shelters: [
    {id:1,name:"Hope Community Kitchen",area:"Shivajinagar",capacity:80,used:48,needs:["Prepared meals","Produce"],handling:["Standard","Keep warm"],emoji:"⌂"},
    {id:2,name:"Green Door Shelter",area:"Kothrud",capacity:55,used:22,needs:["Fruit","Sealed snacks"],handling:["Standard","Fragile packaging"],emoji:"⌂"},
    {id:3,name:"Sunrise Family Centre",area:"Aundh",capacity:65,used:50,needs:["Dairy","Produce"],handling:["Standard","Keep chilled"],emoji:"⌂"},
    {id:4,name:"Neighbourhood Relief Hub",area:"Deccan",capacity:45,used:15,needs:["Bakery","Prepared meals"],handling:["Standard","Keep warm","Fragile packaging"],emoji:"⌂"},
    {id:5,name:"Open Arms Pantry",area:"Baner",capacity:70,used:30,needs:["Produce","Fruit"],handling:["Standard","Keep chilled"],emoji:"⌂"},
    {id:6,name:"Campus Community Shelf",area:"University Road",capacity:35,used:12,needs:["Sealed snacks","Bakery"],handling:["Standard","Fragile packaging"],emoji:"⌂"}
  ],
  mealsRescued:248
};

let state = loadState();
let toastTimer;
const $ = (selector, root=document) => root.querySelector(selector);
const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];

function loadState(){
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if(saved){ const parsed=JSON.parse(saved); if(parsed && parsed.donations && parsed.riders && parsed.shelters) return parsed; }
  } catch(e) { console.warn("Could not read demo storage",e); }
  return structuredClone(initialData);
}
function saveState(){ try { localStorage.setItem(STORAGE_KEY,JSON.stringify(state)); } catch(e){ showToast("Browser storage is unavailable. Changes may not persist."); } }
function esc(value){ return String(value ?? "").replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function deadlineText(minutes){
  if(minutes<=0) return "Deadline passed";
  if(minutes<60) return `${minutes} min`;
  const h=Math.floor(minutes/60),m=minutes%60;
  return m ? `${h}h ${m}m` : `${h}h`;
}
function statusClass(status){ return `status-${status}`; }
function statusPill(status){ return `<span class="status-pill ${statusClass(status)}">${esc(status)}</span>`; }
function donationRow(d, compact=false){
  const urgent=d.deadline<=60 && d.status!=="Collected";
  const food=`<div class="food-cell"><span class="food-emoji">${esc(d.emoji||"🥗")}</span><div class="food-name"><strong>${esc(d.food)}</strong><small>${esc(d.donor)}</small></div></div>`;
  if(compact) return `<tr><td>${food}</td><td>${d.quantity} meals</td><td class="${urgent?"deadline-urgent":"deadline-normal"}">${deadlineText(d.deadline)}</td><td>${statusPill(d.status)}</td></tr>`;
  return `<tr><td>${food}</td><td>${d.quantity} meals</td><td>${esc(d.location)}</td><td class="${urgent?"deadline-urgent":"deadline-normal"}">${deadlineText(d.deadline)}</td><td>${esc(d.handling)}</td><td>${statusPill(d.status)}</td><td>${d.status==="Available"?`<button class="action-button" data-match="${d.id}">Find rider</button>`:`<button class="action-button" data-unmatch="${d.id}">${d.status==="Matched"?"Reopen":"Collected"}</button>`}</td></tr>`;
}
function renderOverview(){
  const active=state.donations.filter(d=>d.status!=="Collected");
  const urgent=active.filter(d=>d.deadline<=60);
  $("#activeDonations").textContent=active.length;
  $("#urgentPickups").textContent=urgent.length;
  $("#availableRiders").textContent=state.riders.filter(r=>r.available).length;
  $("#mealsRescued").textContent=state.mealsRescued;
  $("#donationNavCount").textContent=active.length;
  $("#urgentTable").innerHTML=(urgent.length?urgent:active).slice(0,4).map(d=>donationRow(d,true)).join("") || `<tr><td colspan="4">No active donations right now.</td></tr>`;
  const ready=state.riders.filter(r=>r.available).length;
  $("#riderReadinessText").textContent=`${ready} available for dispatch`;
  $("#riderReadinessNum").textContent=`${ready}/${state.riders.length}`;
  $("#riderProgress").style.width=`${state.riders.length?ready/state.riders.length*100:0}%`;
}
function renderDonations(){
  const search=($("#donationSearch")?.value||"").trim().toLowerCase();
  const filter=$("#statusFilter")?.value||"all";
  const filtered=state.donations.filter(d=>(filter==="all"||d.status===filter)&&[d.food,d.donor,d.location,d.handling,d.status].join(" ").toLowerCase().includes(search));
  $("#donationsTable").innerHTML=filtered.map(d=>donationRow(d,false)).join("");
  $("#emptyDonations").classList.toggle("hidden",filtered.length>0);
  $("#donationCountLabel").textContent=`${filtered.length} record${filtered.length===1?"":"s"}`;
  $("#donationListDescription").textContent=`${filtered.length} donation${filtered.length===1?"":"s"} shown.`;
}
function canHandle(rider,handling){
  if(handling==="Keep chilled") return rider.equipment.includes("Insulated bag");
  if(handling==="Fragile packaging") return rider.equipment.includes("Secure crate");
  if(handling==="Keep warm") return rider.equipment.includes("Insulated bag");
  return true;
}
function bestMatch(donation){
  const candidates=state.riders.filter(r=>r.available && r.capacity>=donation.quantity && canHandle(r,donation.handling));
  candidates.sort((a,b)=>{
    const score=r=>Math.max(0,100-(r.distance+donation.distance)*5-Math.max(0,r.capacity-donation.quantity)*.25);
    return score(b)-score(a);
  });
  return candidates[0]||null;
}
function renderDispatch(){
  const open=state.donations.filter(d=>d.status==="Available");
  $("#openDeliveryCount").textContent=`${open.length} open`;
  $("#openDeliveries").innerHTML=open.map(d=>`<div class="dispatch-item"><span class="food-emoji">${esc(d.emoji||"🥗")}</span><div class="dispatch-item-main"><strong>${esc(d.food)}</strong><small>${esc(d.location)} · ${d.quantity} meal-equivalents</small><div class="dispatch-meta"><span class="tiny-chip">◷ ${deadlineText(d.deadline)}</span><span class="tiny-chip">${esc(d.handling)}</span></div></div><button class="action-button" data-match="${d.id}">Match</button></div>`).join("") || `<div class="empty-state">No open deliveries. Add a donation or reopen a matched delivery.</div>`;
  const matches=open.map(d=>({d,r:bestMatch(d)})).sort((a,b)=>a.d.deadline-b.d.deadline);
  $("#matchSuggestions").innerHTML=matches.slice(0,6).map(({d,r})=>`<div class="dispatch-item"><span class="food-emoji">${r?"✦":"⚠"}</span><div class="dispatch-item-main"><strong>${r?esc(r.name):"No compatible rider yet"}</strong><small>${esc(d.food)} · ${r?`${esc(r.vehicle)} · ${r.capacity} meal capacity`:"Check capacity, availability, or handling equipment"}</small><div class="dispatch-meta"><span class="tiny-chip">${r?`Approx. ${Math.round((r.distance+d.distance)*3)} min travel estimate`:"Needs manual review"}</span><span class="tiny-chip">${esc(d.handling)}</span></div></div><span class="match-score">${r?"MATCH":"REVIEW"}</span></div>`).join("") || `<div class="empty-state">No recommendations until new donations are available.</div>`;
}
function renderRiders(){
  $("#riderGrid").innerHTML=state.riders.map(r=>`<article class="person-card"><div class="person-top"><div class="person-avatar">${esc(r.initials)}</div><div><strong>${esc(r.name)}</strong><small>${esc(r.vehicle)}</small></div>${r.available?`<span class="status-pill status-Available">Available</span>`:`<span class="status-pill status-Collected">Busy</span>`}</div><div class="person-details"><div class="detail-line"><span>Meal capacity</span><strong>${r.capacity} meal-equivalents</strong></div><div class="detail-line"><span>Estimated distance</span><strong>${r.distance.toFixed(1)} km</strong></div><div class="detail-line"><span>Equipment</span><strong>${r.equipment.map(esc).join(", ")}</strong></div></div><button class="secondary-button" data-rider-toggle="${r.id}" style="width:100%">${r.available?"Mark as busy":"Mark available"}</button></article>`).join("");
}
function renderShelters(){
  $("#shelterGrid").innerHTML=state.shelters.map(s=>{const free=Math.max(0,s.capacity-s.used),pct=Math.min(100,s.used/s.capacity*100);return `<article class="shelter-card"><div class="shelter-icon">${esc(s.emoji)}</div><h3>${esc(s.name)}</h3><p>⌖ ${esc(s.area)}</p><div class="detail-line"><span>Receiving capacity</span><strong>${free} of ${s.capacity} meal-equivalents free</strong></div><div class="capacity-bar"><span style="width:${pct}%"></span></div><div class="shelter-needs">${s.needs.map(n=>`<span>${esc(n)}</span>`).join("")}</div><div class="shelter-needs">${s.handling.map(n=>`<span>✓ ${esc(n)}</span>`).join("")}</div></article>`;}).join("");
}
function renderAll(){renderOverview();renderDonations();renderDispatch();renderRiders();renderShelters();}
function showToast(message){
  const toast=$("#toast");toast.textContent=message;toast.classList.remove("hidden");
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.add("hidden"),3200);
}
function navigate(view){
  const target=$("#view-"+view);if(!target)return;
  $$(".view").forEach(v=>v.classList.toggle("active",v===target));
  $$(".nav-item[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  const names={overview:"Overview",donations:"Food donations",dispatch:"Dispatch board",riders:"Volunteer riders",shelters:"Receiving shelters",about:"About RescueRoute"};
  $("#breadcrumbCurrent").textContent=names[view]||"Overview";
  $("#sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"});
}
function openDonationModal(){
  const modal=$("#donationModal");modal.classList.remove("hidden");
  const now=new Date(Date.now()+60*60*1000);now.setMinutes(now.getMinutes()-now.getTimezoneOffset());
  $("#donationForm").elements.deadline.min=new Date().toISOString().slice(0,16);
  $("#donationForm").elements.deadline.value=now.toISOString().slice(0,16);
  setTimeout(()=>$("#donationForm").elements.food.focus(),50);
}
function closeDonationModal(){$("#donationModal").classList.add("hidden");}
function createDonation(form){
  const data=new FormData(form),deadlineDate=new Date(data.get("deadline"));
  const mins=Math.max(1,Math.round((deadlineDate.getTime()-Date.now())/60000));
  if(Number.isNaN(deadlineDate.getTime())||mins<1){showToast("Choose a future pickup deadline.");return;}
  const food=String(data.get("food")).trim(),donor=String(data.get("donor")).trim(),location=String(data.get("location")).trim();
  if(!food||!donor||!location){showToast("Please fill in all required fields.");return;}
  const emojiMap={"keep chilled":"🥛","keep warm":"🍱","fragile packaging":"🥖","standard":"🥬"};
  state.donations.unshift({id:Date.now(),food,donor,quantity:Number(data.get("quantity")),location,deadline:mins,handling:data.get("handling"),status:"Available",notes:String(data.get("notes")||"").trim(),emoji:emojiMap[String(data.get("handling")).toLowerCase()]||"🥗",distance:3.5});
  saveState();renderAll();closeDonationModal();form.reset();showToast("Donation added to the rescue network.");
}
function matchDonation(id){
  const d=state.donations.find(x=>x.id===Number(id));if(!d)return;
  if(d.status!=="Available"){showToast("This donation is not currently open for matching.");return;}
  const r=bestMatch(d);
  if(!r){showToast("No compatible rider available. Check capacity, equipment, or availability.");return;}
  d.status="Matched";r.available=false;
  saveState();renderAll();showToast(`Demo match created: ${r.name} ↔ ${d.food}. Confirm with the rider before dispatch.`);
}
function reopenDonation(id){
  const d=state.donations.find(x=>x.id===Number(id));if(!d)return;
  if(d.status==="Matched"){
    const candidate=state.riders.find(r=>!r.available && r.id===d.assignedRiderId);
    if(candidate)candidate.available=true;
    d.status="Available";delete d.assignedRiderId;saveState();renderAll();showToast("Delivery returned to the open queue.");
  } else if(d.status==="Available"){showToast("This donation is already open.");}
  else {d.status="Available";saveState();renderAll();showToast("Donation reopened.");}
}
function assignMatch(id){
  const d=state.donations.find(x=>x.id===Number(id));if(!d)return;
  const r=bestMatch(d);if(!r){showToast("No compatible rider available right now.");return;}
  d.assignedRiderId=r.id;d.status="Matched";r.available=false;saveState();renderAll();
  showToast(`Demo match created with ${r.name}. Confirm availability before dispatch.`);
}

$$(".nav-item[data-view]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.view)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.go)));
$("#addDonationTop").addEventListener("click",openDonationModal);
$("#addDonationButton").addEventListener("click",openDonationModal);
$("#closeModal").addEventListener("click",closeDonationModal);
$("#cancelModal").addEventListener("click",closeDonationModal);
$("#donationModal").addEventListener("click",e=>{if(e.target===$("#donationModal"))closeDonationModal();});
$("#donationForm").addEventListener("submit",e=>{e.preventDefault();createDonation(e.currentTarget);});
$("#donationSearch").addEventListener("input",renderDonations);
$("#statusFilter").addEventListener("change",renderDonations);
$("#viewDispatchButton").addEventListener("click",()=>navigate("dispatch"));
$("#helpButton").addEventListener("click",()=>showToast("Tip: add a donation, open Dispatch, then choose Match to try the demo workflow."));
$("#mobileMenu").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));
$("#runMatching").addEventListener("click",()=>{renderDispatch();const available=state.donations.filter(d=>d.status==="Available");const count=available.filter(d=>bestMatch(d)).length;showToast(`Matching refreshed: ${count} of ${available.length} open donations have a compatible rider.`);});
$("#toggleRiderAvailability").addEventListener("click",()=>{const rider=state.riders[0];rider.available=!rider.available;saveState();renderAll();showToast(`${rider.name} marked ${rider.available?"available":"busy"}.`);});
document.addEventListener("click",e=>{
  const match=e.target.closest("[data-match]");if(match){assignMatch(match.dataset.match);return;}
  const unmatch=e.target.closest("[data-unmatch]");if(unmatch){reopenDonation(unmatch.dataset.unmatch);return;}
  const rider=e.target.closest("[data-rider-toggle]");if(rider){const r=state.riders.find(x=>x.id===Number(rider.dataset.riderToggle));if(r){r.available=!r.available;saveState();renderAll();showToast(`${r.name} marked ${r.available?"available":"busy"}.`);}return;}
});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeDonationModal();});
$("#donationsTable").addEventListener("click",()=>{});

// Initial render from browser storage (falls back to the sample data on first visit).
renderAll();
